﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hrutsspilid
{
    public partial class Form1 : Form
    {
        Gagnagrunnur gagnagrunnur = new Gagnagrunnur();
        
        public Form1()
        {
            InitializeComponent();
            try
            {
                gagnagrunnur.TengingVidGagnagrunn();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
                throw;
            }
        }
        Random random = new Random();//bý til random
        List<int> spilLeikmadur = new List<int>();//bý til streng fyrir leikmannin
        List<int> spilTolva = new List<int>();//bý til streng fyrir tölvuna
        List<int> spilGeymsla = new List<int>();//bý til string fyrir geymsluna

        private void btnDraga_Click(object sender, EventArgs e)//Takkinn draga byrjar
        {
            int temp = 0;

            for (int i = 0; i < 26; i++)//skipti spilunum i tvennt
            {
                temp = random.Next(1, 53);//gef 26 random spil til leikmannsins
                if (!spilLeikmadur.Contains(temp))
                {
                    spilLeikmadur.Add(temp);
                }

                else
                {
                    i--;
                }
            }

            for (int i = 0; i < 26; i++)//hinn helmingurinn af spilunum
            {
                temp = random.Next(1, 53);//gef 26 random spil til tölvunnar
                if (!spilLeikmadur.Contains(temp) && !spilTolva.Contains(temp))
                {
                    spilTolva.Add(temp);
                }

                else
                {
                    i--;
                }
            }
            panel2.BackgroundImage = imageList1.Images[spilLeikmadur[0]];
            
            MessageBox.Show("Veldu flokk til þess að spila");
            btnDraga.Enabled = false;
            panel2.BackgroundImage = imageList1.Images[spilLeikmadur[0]];
        }//Takkinn draga endar
        int buttonClicked = 0;//Búið til buttonclick

        private void btnWeight_Click(object sender, EventArgs e)//bý til click aðferð
        {
            Button tempbutton = (Button)sender;
            buttonClicked = tempbutton.TabIndex;
        }
        string query = null;
        string query2 = null;

        private void btnSpila_Click(object sender, EventArgs e)//button spila byrjar
        {
            panel2.BackgroundImage = imageList1.Images[spilLeikmadur[0]];
            

            if (buttonClicked == null) { MessageBox.Show("Þú þarft að velja flokk til að spila með"); }
            else
            { 
                if (buttonClicked == 4)//ef þyngd er valin
                {//button 4 byrjar
                    query = "SELECT * FROM hrutaspil WHERE ID= ' " + spilLeikmadur[0] + "'";
                    List<string> lines = new List<string>();

                    string[] arr = new string[2];
                    try
                    {
                        lines = gagnagrunnur.LesautSQLToflu(query);

                        foreach (string lin in lines)
                        {
                            string[] linaFromList = lin.Split(':');
                            arr[0] = linaFromList[2];//þyngd tekin úr gagnagrunni

                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.ToString());
                    }
                    query2 = "SELECT * FROM hrutaspil WHERE ID='" + spilTolva[0] + "'";
                    List<string> lines2 = new List<string>();

                    try
                    {
                        lines2 = gagnagrunnur.LesautSQLToflu(query2);

                        foreach (string lin in lines2)
                        {
                            string[] linaFromList2 = lin.Split(':');
                            arr[1] = linaFromList2[2];//þyngd tekin úr gagnagrunni

                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.ToString());
                    }
                    MessageBox.Show("Leikmaður er með " + arr[0] + " og tölvan er með " + arr[1]);

                    if (Convert.ToDouble(arr[0]) > Convert.ToDouble(arr[1]))
                    {
                        MessageBox.Show("Þú vinnur :)");

                        spilLeikmadur.Add(spilTolva[0]);
                        spilTolva.Remove(spilTolva[0]);

                        if (spilGeymsla.Count > 0)
                        {
                            spilLeikmadur.AddRange(spilGeymsla);
                        }

                        

                    }
                    else if (Convert.ToDouble(arr[0]) < Convert.ToDouble(arr[1]))
                    {
                        MessageBox.Show("þú tapaðir :(");

                        spilTolva.Add(spilLeikmadur[0]);
                        spilLeikmadur.Remove(spilLeikmadur[0]);
                        if (spilGeymsla.Count > 0)
                        {
                            spilTolva.AddRange(spilGeymsla);
                        }
                        

                    }
                    else
                    {
                        MessageBox.Show("Jafntefli");

                        spilGeymsla.Add(spilLeikmadur[0]);
                        spilGeymsla.Add(spilTolva[0]);
                        spilLeikmadur.Remove(spilLeikmadur[0]);
                        spilTolva.Remove(spilTolva[0]);

                        
                    }
                    panel2.BackgroundImage = imageList1.Images[spilLeikmadur[0]];


                }//button 4 endar
                else if (buttonClicked == 5)//ef mjólk er valin
                {//button 5 byrjar
                    query = "SELECT * FROM hrutaspil WHERE ID='" + spilLeikmadur[0] + "'";
                    List<string> lines = new List<string>();

                    string[] arr = new string[2];
                    try
                    {
                        lines = gagnagrunnur.LesautSQLToflu(query);

                        foreach (string lin in lines)
                        {
                            string[] linaFromList = lin.Split(':');
                            arr[0] = linaFromList[3];//mjólk tekin úr gagnagrunni

                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.ToString());
                    }
                    query2 = "SELECT * FROM hrutaspil WHERE ID='" + spilTolva[0] + "'";
                    List<string> lines2 = new List<string>();

                    try
                    {
                        lines2 = gagnagrunnur.LesautSQLToflu(query2);

                        foreach (string lin in lines2)
                        {
                            string[] linaFromList2 = lin.Split(':');
                            arr[1] = linaFromList2[3];//mjólk tekin úr gagnagrunni

                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.ToString());
                    }
                    MessageBox.Show("Leikmaður er með " + arr[0] + " og tölvan er með " + arr[1]);

                    if (Convert.ToDouble(arr[0]) > Convert.ToDouble(arr[1]))
                    {
                        MessageBox.Show("þú vinnur :)");

                        spilLeikmadur.Add(spilTolva[0]);
                        spilTolva.Remove(spilTolva[0]);

                        if (spilGeymsla.Count > 0)
                        {
                            spilLeikmadur.AddRange(spilGeymsla);
                        }

                        

                    }
                    else if (Convert.ToDouble(arr[0]) < Convert.ToDouble(arr[1]))
                    {
                        MessageBox.Show("þú tapaðir :(");

                        spilTolva.Add(spilLeikmadur[0]);
                        spilLeikmadur.Remove(spilLeikmadur[0]);
                        if (spilGeymsla.Count > 0)
                        {
                            spilTolva.AddRange(spilGeymsla);
                        }
                        

                    }
                    else
                    {
                        MessageBox.Show("Jafntefli");

                        spilGeymsla.Add(spilLeikmadur[0]);
                        spilGeymsla.Add(spilTolva[0]);
                        spilLeikmadur.Remove(spilLeikmadur[0]);
                        spilTolva.Remove(spilTolva[0]);

                       
                    }
                    MessageBox.Show("þú valdir mjólkurdrægni" + arr[1]);
                    panel2.BackgroundImage = imageList1.Images[spilLeikmadur[0]];

                }//button 5 endar
                else if (buttonClicked == 6)//ef ull er valin
                {//button 6 byrjar
                    query = "SELECT * FROM hrutaspil WHERE ID='" + spilLeikmadur[0] + "'";
                    List<string> lines = new List<string>();

                    string[] arr = new string[2];
                    try
                    {
                        lines = gagnagrunnur.LesautSQLToflu(query);

                        foreach (string lin in lines)
                        {
                            string[] linaFromList = lin.Split(':');
                            arr[0] = linaFromList[4];//ull tekin úr gagnagrunni

                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.ToString());
                    }
                    query2 = "SELECT * FROM hrutaspil WHERE ID='" + spilTolva[0] + "'";
                    List<string> lines2 = new List<string>();

                    try
                    {
                        lines2 = gagnagrunnur.LesautSQLToflu(query2);

                        foreach (string lin in lines2)
                        {
                            string[] linaFromList2 = lin.Split(':');
                            arr[1] = linaFromList2[4];//ull tekin úr gagnagrunni

                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.ToString());
                    }
                    MessageBox.Show("Leikmaður er með " + arr[0] + " og tölvan er með " + arr[1]);

                    if (Convert.ToDouble(arr[0]) > Convert.ToDouble(arr[1]))
                    {
                        MessageBox.Show("Þú vinnur :)");

                        spilLeikmadur.Add(spilTolva[0]);
                        spilTolva.Remove(spilTolva[0]);

                        if (spilGeymsla.Count > 0)
                        {
                            spilLeikmadur.AddRange(spilGeymsla);
                        }

                        

                    }
                    else if (Convert.ToDouble(arr[0]) < Convert.ToDouble(arr[1]))
                    {
                        MessageBox.Show("þú tapaðir :(");

                        spilTolva.Add(spilLeikmadur[0]);
                        spilLeikmadur.Remove(spilLeikmadur[0]);
                        if (spilGeymsla.Count > 0)
                        {
                            spilTolva.AddRange(spilGeymsla);
                        }
                        

                    }
                    else
                    {
                        MessageBox.Show("Jafntefli");

                        spilGeymsla.Add(spilLeikmadur[0]);
                        spilGeymsla.Add(spilTolva[0]);
                        spilLeikmadur.Remove(spilLeikmadur[0]);
                        spilTolva.Remove(spilTolva[0]);

                        
                    }
                    panel2.BackgroundImage = imageList1.Images[spilLeikmadur[0]];

                }//button 6 endar
                else if (buttonClicked == 7)//ef afkvæmi eru valin
                {//button 7 byrjar
                    query = "SELECT * FROM hrutaspil WHERE ID='" + spilLeikmadur[0] + "'";
                    List<string> lines = new List<string>();

                    string[] arr = new string[2];
                    try
                    {
                        lines = gagnagrunnur.LesautSQLToflu(query);

                        foreach (string lin in lines)
                        {
                            string[] linaFromList = lin.Split(':');
                            arr[0] = linaFromList[5];//afkvæmi tekin úr gagnagrunni

                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.ToString());
                    }
                    query2 = "SELECT * FROM hrutaspil WHERE ID='" + spilTolva[0] + "'";
                    List<string> lines2 = new List<string>();

                    try
                    {
                        lines2 = gagnagrunnur.LesautSQLToflu(query2);

                        foreach (string lin in lines2)
                        {
                            string[] linaFromList2 = lin.Split(':');
                            arr[1] = linaFromList2[5];//afkvæmi tekin úr gagnagrunni

                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.ToString());
                    }
                    MessageBox.Show("Leikmaður er með " + arr[0] + " og tölvan er með " + arr[1]);

                    if (Convert.ToDouble(arr[0]) > Convert.ToDouble(arr[1]))
                    {
                        MessageBox.Show("þú vinnur :)");

                        spilLeikmadur.Add(spilTolva[0]);
                        spilTolva.Remove(spilTolva[0]);

                        if (spilGeymsla.Count > 0)
                        {
                            spilLeikmadur.AddRange(spilGeymsla);
                        }

                        

                    }
                    else if (Convert.ToDouble(arr[0]) < Convert.ToDouble(arr[1]))
                    {
                        MessageBox.Show("þú tapaðir :(");

                        spilTolva.Add(spilLeikmadur[0]);
                        spilLeikmadur.Remove(spilLeikmadur[0]);
                        if (spilGeymsla.Count > 0)
                        {
                            spilTolva.AddRange(spilGeymsla);
                        }
                        
                    }
                    else
                    {
                        MessageBox.Show("Jafntefli");

                        spilGeymsla.Add(spilLeikmadur[0]);
                        spilGeymsla.Add(spilTolva[0]);
                        spilLeikmadur.Remove(spilLeikmadur[0]);
                        spilTolva.Remove(spilTolva[0]);

                        
                    }
                    panel2.BackgroundImage = imageList1.Images[spilLeikmadur[0]];

                }//button 7 endar
                else if (buttonClicked == 8)//ef fætur eru valdnar
                {//button 8 byrjar
                    query = "SELECT * FROM hrutaspil WHERE ID='" + spilLeikmadur[0] + "'";
                    List<string> lines = new List<string>();

                    string[] arr = new string[2];
                    try
                    {
                        lines = gagnagrunnur.LesautSQLToflu(query);

                        foreach (string lin in lines)
                        {
                            string[] linaFromList = lin.Split(':');
                            arr[0] = linaFromList[6];//fætur tekin úr gagnagrunni

                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.ToString());
                    }
                    query2 = "SELECT * FROM hrutaspil WHERE ID='" + spilTolva[0] + "'";
                    List<string> lines2 = new List<string>();

                    try
                    {
                        lines2 = gagnagrunnur.LesautSQLToflu(query2);

                        foreach (string lin in lines2)
                        {
                            string[] linaFromList2 = lin.Split(':');
                            arr[1] = linaFromList2[6];//fætur tekin úr gagnagrunni

                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.ToString());
                    }
                    MessageBox.Show("Leikmaður er með " + arr[0] + " og tölvan er með " + arr[1]);

                    if (Convert.ToDouble(arr[0]) > Convert.ToDouble(arr[1]))
                    {
                        MessageBox.Show("þú vinnur :)");

                        spilLeikmadur.Add(spilTolva[0]);
                        spilTolva.Remove(spilTolva[0]);

                        if (spilGeymsla.Count > 0)
                        {
                            spilLeikmadur.AddRange(spilGeymsla);
                        }

                        

                    }
                    else if (Convert.ToDouble(arr[0]) < Convert.ToDouble(arr[1]))
                    {
                        MessageBox.Show("þú tapaðir :(");

                        spilTolva.Add(spilLeikmadur[0]);
                        spilLeikmadur.Remove(spilLeikmadur[0]);
                        if (spilGeymsla.Count > 0)
                        {
                            spilTolva.AddRange(spilGeymsla);
                        }
                        

                    }
                    else
                    {
                        MessageBox.Show("Jafntefli");

                        spilGeymsla.Add(spilLeikmadur[0]);
                        spilGeymsla.Add(spilTolva[0]);
                        spilLeikmadur.Remove(spilLeikmadur[0]);
                        spilTolva.Remove(spilTolva[0]);

                        
                    }
                    panel2.BackgroundImage = imageList1.Images[spilLeikmadur[0]];

                }//button 8 endar
                else if (buttonClicked == 9)//ef kyn er valið
                {//button 9 byrjar
                    query = "SELECT * FROM hrutaspil WHERE ID='" + spilLeikmadur[0] + "'";
                    List<string> lines = new List<string>();

                    string[] arr = new string[2];
                    try
                    {
                        lines = gagnagrunnur.LesautSQLToflu(query);

                        foreach (string lin in lines)
                        {
                            string[] linaFromList = lin.Split(':');
                            arr[0] = linaFromList[7];//kyn tekin úr gagnagrunni

                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.ToString());
                    }
                    query2 = "SELECT * FROM hrutaspil WHERE ID='" + spilTolva[0] + "'";
                    List<string> lines2 = new List<string>();

                    try
                    {
                        lines2 = gagnagrunnur.LesautSQLToflu(query2);

                        foreach (string lin in lines2)
                        {
                            string[] linaFromList2 = lin.Split(':');
                            arr[1] = linaFromList2[7];//kyn tekin úr gagnagrunni

                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.ToString());
                    }
                    MessageBox.Show("Leikmaður er með " + arr[0] + " og tölvan er með " + arr[1]);

                    if (Convert.ToDouble(arr[0]) > Convert.ToDouble(arr[1]))
                    {
                        MessageBox.Show("þú vinnur :)");

                        spilLeikmadur.Add(spilTolva[0]);
                        spilTolva.Remove(spilTolva[0]);

                        if (spilGeymsla.Count > 0)
                        {
                            spilLeikmadur.AddRange(spilGeymsla);
                        }

                       
                    }
                    else if (Convert.ToDouble(arr[0]) < Convert.ToDouble(arr[1]))
                    {
                        MessageBox.Show("þú tapaðir :( ");

                        spilTolva.Add(spilLeikmadur[0]);
                        spilLeikmadur.Remove(spilLeikmadur[0]);
                        if (spilGeymsla.Count > 0)
                        {
                            spilTolva.AddRange(spilGeymsla);
                        }
                        

                    }
                    else
                    {
                        MessageBox.Show("Jafntefli");

                        spilGeymsla.Add(spilLeikmadur[0]);
                        spilGeymsla.Add(spilTolva[0]);
                        spilLeikmadur.Remove(spilLeikmadur[0]);
                        spilTolva.Remove(spilTolva[0]);

                        
                    }
                    panel2.BackgroundImage = imageList1.Images[spilLeikmadur[0]];

                }//button 9 endar
                else if (buttonClicked == 10)//ef bakvöðvar eru valdnir
                {//button 10 byrjar
                    query = "SELECT * FROM hrutaspil WHERE ID='" + spilLeikmadur[0] + "'";
                    List<string> lines = new List<string>();

                    string[] arr = new string[2];
                    try
                    {
                        lines = gagnagrunnur.LesautSQLToflu(query);

                        foreach (string lin in lines)
                        {
                            string[] linaFromList = lin.Split(':');
                            arr[0] = linaFromList[8];//bakvöðvar tekin úr gagnagrunni

                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.ToString());
                    }
                    query2 = "SELECT * FROM hrutaspil WHERE ID='" + spilTolva[0] + "'";
                    List<string> lines2 = new List<string>();

                    try
                    {
                        lines2 = gagnagrunnur.LesautSQLToflu(query2);

                        foreach (string lin in lines2)
                        {
                            string[] linaFromList2 = lin.Split(':');
                            arr[1] = linaFromList2[8];//bakvöðvar tekin úr gagnagrunni

                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.ToString());
                    }
                    MessageBox.Show("Leikmaður er með " + arr[0] + " og tölvan er með " + arr[1]);

                    if (Convert.ToDouble(arr[0]) > Convert.ToDouble(arr[1]))
                    {
                        MessageBox.Show("þú vinnur :)");

                        spilLeikmadur.Add(spilTolva[0]);
                        spilTolva.Remove(spilTolva[0]);

                        if (spilGeymsla.Count > 0)
                        {
                            spilLeikmadur.AddRange(spilGeymsla);
                        }

                        

                    }
                    else if (Convert.ToDouble(arr[0]) < Convert.ToDouble(arr[1]))
                    {
                        MessageBox.Show("þú tapaðir :(");

                        spilTolva.Add(spilLeikmadur[0]);
                        spilLeikmadur.Remove(spilLeikmadur[0]);
                        if (spilGeymsla.Count > 0)
                        {
                            spilTolva.AddRange(spilGeymsla);
                        }
                        
                    }
                    else
                    {
                        MessageBox.Show("Jafntefli");

                        spilGeymsla.Add(spilLeikmadur[0]);
                        spilGeymsla.Add(spilTolva[0]);
                        spilLeikmadur.Remove(spilLeikmadur[0]);
                        spilTolva.Remove(spilTolva[0]);

                        
                    }
                    panel2.BackgroundImage = imageList1.Images[spilLeikmadur[0]];

                }//button 10 endar
                else if (buttonClicked == 11)//ef rassvöðvar eru valdnir
                {//button 11 byrjar
                    query = "SELECT * FROM hrutaspil WHERE ID='" + spilLeikmadur[0] + "'";
                    List<string> lines = new List<string>();

                    string[] arr = new string[2];
                    try
                    {
                        lines = gagnagrunnur.LesautSQLToflu(query);

                        foreach (string lin in lines)
                        {
                            string[] linaFromList = lin.Split(':');
                            arr[0] = linaFromList[9];//rassvöðvar tekin úr gagnagrunni

                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.ToString());
                    }
                    query2 = "SELECT * FROM hrutaspil WHERE ID='" + spilTolva[0] + "'";
                    List<string> lines2 = new List<string>();

                    try
                    {
                        lines2 = gagnagrunnur.LesautSQLToflu(query2);

                        foreach (string lin in lines2)
                        {
                            string[] linaFromList2 = lin.Split(':');
                            arr[1] = linaFromList2[9];//rassvöðvar tekin úr gagnagrunni

                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.ToString());
                    }
                    MessageBox.Show("Leikmaður er með " + arr[0] + " og tölvan er með " + arr[1]);

                    if (Convert.ToDouble(arr[0]) > Convert.ToDouble(arr[1]))
                    {
                        MessageBox.Show("þú vinnur :)");

                        spilLeikmadur.Add(spilTolva[0]);
                        spilTolva.Remove(spilTolva[0]);

                        if (spilGeymsla.Count > 0)
                        {
                            spilLeikmadur.AddRange(spilGeymsla);
                        }

                        

                    }
                    else if (Convert.ToDouble(arr[0]) < Convert.ToDouble(arr[1]))
                    {
                        MessageBox.Show("þú tapaðir :(");

                        spilTolva.Add(spilLeikmadur[0]);
                        spilLeikmadur.Remove(spilLeikmadur[0]);
                        if (spilGeymsla.Count > 0)
                        {
                            spilTolva.AddRange(spilGeymsla);
                        }
                        
                    }
                    else
                    {
                        MessageBox.Show("Jafntefli");

                        spilGeymsla.Add(spilLeikmadur[0]);
                        spilGeymsla.Add(spilTolva[0]);
                        spilLeikmadur.Remove(spilLeikmadur[0]);
                        spilTolva.Remove(spilTolva[0]);

                        
                    }
                    panel2.BackgroundImage = imageList1.Images[spilLeikmadur[0]];

                }//button 11 endar
            }
        }//button spila endar

        
        




        
    }
}
