﻿namespace Hrutsspilid
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.btnDraga = new System.Windows.Forms.Button();
            this.btnSpila = new System.Windows.Forms.Button();
            this.btnWeight = new System.Windows.Forms.Button();
            this.btnMilk = new System.Windows.Forms.Button();
            this.btnUll = new System.Windows.Forms.Button();
            this.btnBaby = new System.Windows.Forms.Button();
            this.btnLegs = new System.Windows.Forms.Button();
            this.btnKyn = new System.Windows.Forms.Button();
            this.btnBak = new System.Windows.Forms.Button();
            this.btnRass = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Location = new System.Drawing.Point(30, 31);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(236, 262);
            this.panel1.TabIndex = 0;
            // 
            // panel2
            // 
            this.panel2.Location = new System.Drawing.Point(272, 31);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(261, 262);
            this.panel2.TabIndex = 1;
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "valgeir.png");
            this.imageList1.Images.SetKeyName(1, "Sokki.GIF");
            this.imageList1.Images.SetKeyName(2, "Freyðir.GIF");
            this.imageList1.Images.SetKeyName(3, "vöðvi.GIF");
            this.imageList1.Images.SetKeyName(4, "Kjói.GIF");
            this.imageList1.Images.SetKeyName(5, "Bogi.GIF");
            this.imageList1.Images.SetKeyName(6, "Falur.GIF");
            this.imageList1.Images.SetKeyName(7, "Borði.GIF");
            this.imageList1.Images.SetKeyName(8, "Bramli.GIF");
            this.imageList1.Images.SetKeyName(9, "Kaldi.GIF");
            this.imageList1.Images.SetKeyName(10, "Vorm.GIF");
            this.imageList1.Images.SetKeyName(11, "Smyrill.GIF");
            this.imageList1.Images.SetKeyName(12, "Prjónn.GIF");
            this.imageList1.Images.SetKeyName(13, "Grabotni.GIF");
            this.imageList1.Images.SetKeyName(14, "Kongur.GIF");
            this.imageList1.Images.SetKeyName(15, "Garpur.GIF");
            this.imageList1.Images.SetKeyName(16, "Broddi.GIF");
            this.imageList1.Images.SetKeyName(17, "Frakkson.GIF");
            this.imageList1.Images.SetKeyName(18, "Þróttur.GIF");
            this.imageList1.Images.SetKeyName(19, "Bifur.GIF");
            this.imageList1.Images.SetKeyName(20, "Stáli.GIF");
            this.imageList1.Images.SetKeyName(21, "Fálki.GIF");
            this.imageList1.Images.SetKeyName(22, "Kjarkur.GIF");
            this.imageList1.Images.SetKeyName(23, "Hólmi.GIF");
            this.imageList1.Images.SetKeyName(24, "Púki.GIF");
            this.imageList1.Images.SetKeyName(25, "Mjöður.GIF");
            this.imageList1.Images.SetKeyName(26, "Mókollur.GIF");
            this.imageList1.Images.SetKeyName(27, "Gotti.GIF");
            this.imageList1.Images.SetKeyName(28, "Hrói.GIF");
            this.imageList1.Images.SetKeyName(29, "Dökkvi.GIF");
            this.imageList1.Images.SetKeyName(30, "Bolli.GIF");
            this.imageList1.Images.SetKeyName(31, "Týr.GIF");
            this.imageList1.Images.SetKeyName(32, "Papi.GIF");
            this.imageList1.Images.SetKeyName(33, "Tengill.GIF");
            this.imageList1.Images.SetKeyName(34, "At.GIF");
            this.imageList1.Images.SetKeyName(35, "Gráni.GIF");
            this.imageList1.Images.SetKeyName(36, "Ylur.GIF");
            this.imageList1.Images.SetKeyName(37, "Neisti.GIF");
            this.imageList1.Images.SetKeyName(38, "Logi.GIF");
            this.imageList1.Images.SetKeyName(39, "Kveikur.GIF");
            this.imageList1.Images.SetKeyName(40, "Shrek.GIF");
            this.imageList1.Images.SetKeyName(41, "Cat.GIF");
            this.imageList1.Images.SetKeyName(42, "Fannar.GIF");
            this.imageList1.Images.SetKeyName(43, "Hvellur.GIF");
            this.imageList1.Images.SetKeyName(44, "Raftur.GIF");
            this.imageList1.Images.SetKeyName(45, "Blossi.GIF");
            this.imageList1.Images.SetKeyName(46, "Blettur.GIF");
            this.imageList1.Images.SetKeyName(47, "Mundi.GIF");
            this.imageList1.Images.SetKeyName(48, "Hriflon.GIF");
            this.imageList1.Images.SetKeyName(49, "Skrauti.GIF");
            this.imageList1.Images.SetKeyName(50, "Krókur.GIF");
            this.imageList1.Images.SetKeyName(51, "Undri.GIF");
            this.imageList1.Images.SetKeyName(52, "Ás.GIF");
            // 
            // btnDraga
            // 
            this.btnDraga.Location = new System.Drawing.Point(272, 319);
            this.btnDraga.Name = "btnDraga";
            this.btnDraga.Size = new System.Drawing.Size(149, 67);
            this.btnDraga.TabIndex = 2;
            this.btnDraga.Text = "Dragðu spil";
            this.btnDraga.UseVisualStyleBackColor = true;
            this.btnDraga.Click += new System.EventHandler(this.btnDraga_Click);
            // 
            // btnSpila
            // 
            this.btnSpila.Location = new System.Drawing.Point(427, 319);
            this.btnSpila.Name = "btnSpila";
            this.btnSpila.Size = new System.Drawing.Size(149, 67);
            this.btnSpila.TabIndex = 3;
            this.btnSpila.Text = "Spila";
            this.btnSpila.UseVisualStyleBackColor = true;
            this.btnSpila.Click += new System.EventHandler(this.btnSpila_Click);
            // 
            // btnWeight
            // 
            this.btnWeight.Location = new System.Drawing.Point(619, 48);
            this.btnWeight.Name = "btnWeight";
            this.btnWeight.Size = new System.Drawing.Size(75, 60);
            this.btnWeight.TabIndex = 4;
            this.btnWeight.Text = "Þyngd";
            this.btnWeight.UseVisualStyleBackColor = true;
            this.btnWeight.Click += new System.EventHandler(this.btnWeight_Click);
            // 
            // btnMilk
            // 
            this.btnMilk.Location = new System.Drawing.Point(700, 48);
            this.btnMilk.Name = "btnMilk";
            this.btnMilk.Size = new System.Drawing.Size(75, 60);
            this.btnMilk.TabIndex = 5;
            this.btnMilk.Text = "Mjólk";
            this.btnMilk.UseVisualStyleBackColor = true;
            this.btnMilk.Click += new System.EventHandler(this.btnWeight_Click);
            // 
            // btnUll
            // 
            this.btnUll.Location = new System.Drawing.Point(781, 48);
            this.btnUll.Name = "btnUll";
            this.btnUll.Size = new System.Drawing.Size(75, 60);
            this.btnUll.TabIndex = 6;
            this.btnUll.Text = "Ull";
            this.btnUll.UseVisualStyleBackColor = true;
            this.btnUll.Click += new System.EventHandler(this.btnWeight_Click);
            // 
            // btnBaby
            // 
            this.btnBaby.Location = new System.Drawing.Point(862, 48);
            this.btnBaby.Name = "btnBaby";
            this.btnBaby.Size = new System.Drawing.Size(75, 60);
            this.btnBaby.TabIndex = 7;
            this.btnBaby.Text = "Afkvæmi";
            this.btnBaby.UseVisualStyleBackColor = true;
            this.btnBaby.Click += new System.EventHandler(this.btnWeight_Click);
            // 
            // btnLegs
            // 
            this.btnLegs.Location = new System.Drawing.Point(619, 146);
            this.btnLegs.Name = "btnLegs";
            this.btnLegs.Size = new System.Drawing.Size(75, 65);
            this.btnLegs.TabIndex = 8;
            this.btnLegs.Text = "Fætur";
            this.btnLegs.UseVisualStyleBackColor = true;
            this.btnLegs.Click += new System.EventHandler(this.btnWeight_Click);
            // 
            // btnKyn
            // 
            this.btnKyn.Location = new System.Drawing.Point(700, 146);
            this.btnKyn.Name = "btnKyn";
            this.btnKyn.Size = new System.Drawing.Size(75, 65);
            this.btnKyn.TabIndex = 9;
            this.btnKyn.Text = "Kyn";
            this.btnKyn.UseVisualStyleBackColor = true;
            this.btnKyn.Click += new System.EventHandler(this.btnWeight_Click);
            // 
            // btnBak
            // 
            this.btnBak.Location = new System.Drawing.Point(781, 146);
            this.btnBak.Name = "btnBak";
            this.btnBak.Size = new System.Drawing.Size(75, 65);
            this.btnBak.TabIndex = 10;
            this.btnBak.Text = "Bakvöðvar";
            this.btnBak.UseVisualStyleBackColor = true;
            this.btnBak.Click += new System.EventHandler(this.btnWeight_Click);
            // 
            // btnRass
            // 
            this.btnRass.Location = new System.Drawing.Point(862, 146);
            this.btnRass.Name = "btnRass";
            this.btnRass.Size = new System.Drawing.Size(75, 65);
            this.btnRass.TabIndex = 11;
            this.btnRass.Text = "Rassvöðvar";
            this.btnRass.UseVisualStyleBackColor = true;
            this.btnRass.Click += new System.EventHandler(this.btnWeight_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(973, 526);
            this.Controls.Add(this.btnRass);
            this.Controls.Add(this.btnBak);
            this.Controls.Add(this.btnKyn);
            this.Controls.Add(this.btnLegs);
            this.Controls.Add(this.btnBaby);
            this.Controls.Add(this.btnUll);
            this.Controls.Add(this.btnMilk);
            this.Controls.Add(this.btnWeight);
            this.Controls.Add(this.btnSpila);
            this.Controls.Add(this.btnDraga);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.Button btnDraga;
        private System.Windows.Forms.Button btnSpila;
        private System.Windows.Forms.Button btnWeight;
        private System.Windows.Forms.Button btnMilk;
        private System.Windows.Forms.Button btnUll;
        private System.Windows.Forms.Button btnBaby;
        private System.Windows.Forms.Button btnLegs;
        private System.Windows.Forms.Button btnKyn;
        private System.Windows.Forms.Button btnBak;
        private System.Windows.Forms.Button btnRass;
    }
}

