﻿namespace Hrutsspilid
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.btSyna = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Location = new System.Drawing.Point(30, 31);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(224, 296);
            this.panel1.TabIndex = 0;
            // 
            // panel2
            // 
            this.panel2.Location = new System.Drawing.Point(319, 31);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(235, 296);
            this.panel2.TabIndex = 1;
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "At.GIF");
            this.imageList1.Images.SetKeyName(1, "Ás.GIF");
            this.imageList1.Images.SetKeyName(2, "Bifur.GIF");
            this.imageList1.Images.SetKeyName(3, "Blettur.GIF");
            this.imageList1.Images.SetKeyName(4, "Blossi.GIF");
            this.imageList1.Images.SetKeyName(5, "Bogi.GIF");
            this.imageList1.Images.SetKeyName(6, "Bolli.GIF");
            this.imageList1.Images.SetKeyName(7, "Borði.GIF");
            this.imageList1.Images.SetKeyName(8, "Bramli.GIF");
            this.imageList1.Images.SetKeyName(9, "Broddi.GIF");
            this.imageList1.Images.SetKeyName(10, "Cat.GIF");
            this.imageList1.Images.SetKeyName(11, "Dökkvi.GIF");
            this.imageList1.Images.SetKeyName(12, "Falur.GIF");
            this.imageList1.Images.SetKeyName(13, "Fannar.GIF");
            this.imageList1.Images.SetKeyName(14, "Fálki.GIF");
            this.imageList1.Images.SetKeyName(15, "Flokkar_ekkispil.GIF");
            this.imageList1.Images.SetKeyName(16, "Frakkson.GIF");
            this.imageList1.Images.SetKeyName(17, "Freyðir.GIF");
            this.imageList1.Images.SetKeyName(18, "Garpur.GIF");
            this.imageList1.Images.SetKeyName(19, "Gotti.GIF");
            this.imageList1.Images.SetKeyName(20, "Grabotni.GIF");
            this.imageList1.Images.SetKeyName(21, "Gráni.GIF");
            this.imageList1.Images.SetKeyName(22, "Hólmi.GIF");
            this.imageList1.Images.SetKeyName(23, "Hriflon.GIF");
            this.imageList1.Images.SetKeyName(24, "Hrói.GIF");
            this.imageList1.Images.SetKeyName(25, "Hvellur.GIF");
            this.imageList1.Images.SetKeyName(26, "Kaldi.GIF");
            this.imageList1.Images.SetKeyName(27, "Kjarkur.GIF");
            this.imageList1.Images.SetKeyName(28, "Kjói.GIF");
            this.imageList1.Images.SetKeyName(29, "Kongur.GIF");
            this.imageList1.Images.SetKeyName(30, "Krókur.GIF");
            this.imageList1.Images.SetKeyName(31, "Kveikur.GIF");
            this.imageList1.Images.SetKeyName(32, "Logi.GIF");
            this.imageList1.Images.SetKeyName(33, "Mjöður.GIF");
            this.imageList1.Images.SetKeyName(34, "Mókollur.GIF");
            this.imageList1.Images.SetKeyName(35, "Mundi.GIF");
            this.imageList1.Images.SetKeyName(36, "Neisti.GIF");
            this.imageList1.Images.SetKeyName(37, "Papi.GIF");
            this.imageList1.Images.SetKeyName(38, "Prjónn.GIF");
            this.imageList1.Images.SetKeyName(39, "Púki.GIF");
            this.imageList1.Images.SetKeyName(40, "Raftur.GIF");
            this.imageList1.Images.SetKeyName(41, "Shrek.GIF");
            this.imageList1.Images.SetKeyName(42, "Skrauti.GIF");
            this.imageList1.Images.SetKeyName(43, "Smyrill.GIF");
            this.imageList1.Images.SetKeyName(44, "Sokki.GIF");
            this.imageList1.Images.SetKeyName(45, "Stáli.GIF");
            this.imageList1.Images.SetKeyName(46, "Tengill.GIF");
            this.imageList1.Images.SetKeyName(47, "Týr.GIF");
            this.imageList1.Images.SetKeyName(48, "Undri.GIF");
            this.imageList1.Images.SetKeyName(49, "Vorm.GIF");
            this.imageList1.Images.SetKeyName(50, "vöðvi.GIF");
            this.imageList1.Images.SetKeyName(51, "Ylur.GIF");
            this.imageList1.Images.SetKeyName(52, "Þróttur.GIF");
            // 
            // btSyna
            // 
            this.btSyna.Location = new System.Drawing.Point(231, 342);
            this.btSyna.Name = "btSyna";
            this.btSyna.Size = new System.Drawing.Size(113, 65);
            this.btSyna.TabIndex = 2;
            this.btSyna.Text = "Sýna";
            this.btSyna.UseVisualStyleBackColor = true;
            this.btSyna.Click += new System.EventHandler(this.btSyna_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(590, 477);
            this.Controls.Add(this.btSyna);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.Button btSyna;
    }
}

